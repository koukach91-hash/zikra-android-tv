ذِكرى Android TV APK project

This ZIP contains the Android project files. The app opens the existing dashboard URL:
https://illustrious-khapse-88e109.netlify.app/

To build using GitHub Actions, upload this ZIP to the repository root as Zikra_AndroidTV_APK_Project.zip and replace .github/workflows/build-apk.yml with the workflow file supplied separately. Then run Actions > Build Zikra APK > Run workflow. Download the APK from the successful run's Artifacts section.

Note: this ZIP does not itself contain a compiled APK. GitHub Actions builds it.
